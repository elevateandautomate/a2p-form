
This system registers SMS brands and campaigns with Twilio using n8n and Supabase.

## Deploy n8n on Render (Recommended: Render Postgres)

1. Sign up for Render: https://dashboard.render.com/register
2. Copy the example template: https://github.com/render-examples/n8n
3. Create a Render Blueprint
4. Upgrade your instances
